# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
This package contains pytest plugins that are used by the astropy test suite.
"""

from .version import version as __version__
