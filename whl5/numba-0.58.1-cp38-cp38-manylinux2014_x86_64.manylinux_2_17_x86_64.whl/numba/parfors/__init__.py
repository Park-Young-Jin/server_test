from numba.parfors import parfor_lowering
