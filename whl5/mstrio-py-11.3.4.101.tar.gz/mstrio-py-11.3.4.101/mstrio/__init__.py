__title__ = "mstrio-py"
__version__ = "11.3.4.101"  # NOSONAR
__dev_version__ = 1054
__license__ = "Apache License 2.0"
__description__ = "Python interface for the MicroStrategy REST API"
__author__ = "MicroStrategy"
__author_email__ = "pkowal@microstrategy.com"
