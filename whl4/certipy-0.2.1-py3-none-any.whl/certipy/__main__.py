from certipy.command_line import main

if __name__ == "__main__":
    main()
