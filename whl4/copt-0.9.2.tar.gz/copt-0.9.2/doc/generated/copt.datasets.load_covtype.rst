﻿copt.datasets.load\_covtype
===========================

.. currentmodule:: copt.datasets

.. autofunction:: load_covtype