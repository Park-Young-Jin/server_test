﻿copt.minimize\_saga
===================

.. currentmodule:: copt

.. autofunction:: minimize_saga