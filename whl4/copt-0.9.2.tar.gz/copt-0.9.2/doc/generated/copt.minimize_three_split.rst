﻿copt.minimize\_three\_split
===========================

.. currentmodule:: copt

.. autofunction:: minimize_three_split