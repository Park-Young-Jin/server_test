﻿copt.datasets.load\_img1
========================

.. currentmodule:: copt.datasets

.. autofunction:: load_img1