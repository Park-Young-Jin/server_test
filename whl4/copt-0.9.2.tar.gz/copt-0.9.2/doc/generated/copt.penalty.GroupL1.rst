﻿copt.penalty.GroupL1
====================

.. currentmodule:: copt.penalty

.. autoclass:: GroupL1

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GroupL1.__init__
      ~GroupL1.prox
      ~GroupL1.prox_factory
   
   

   
   
   