﻿copt.datasets.load\_rcv1
========================

.. currentmodule:: copt.datasets

.. autofunction:: load_rcv1