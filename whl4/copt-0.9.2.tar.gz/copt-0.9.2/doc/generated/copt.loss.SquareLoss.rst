﻿copt.loss.SquareLoss
====================

.. currentmodule:: copt.loss

.. autoclass:: SquareLoss

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~SquareLoss.__init__
      ~SquareLoss.f_grad
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~SquareLoss.lipschitz
      ~SquareLoss.max_lipschitz
      ~SquareLoss.partial_deriv
   
   