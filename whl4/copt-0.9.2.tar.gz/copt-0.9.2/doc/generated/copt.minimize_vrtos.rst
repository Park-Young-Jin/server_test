﻿copt.minimize\_vrtos
====================

.. currentmodule:: copt

.. autofunction:: minimize_vrtos