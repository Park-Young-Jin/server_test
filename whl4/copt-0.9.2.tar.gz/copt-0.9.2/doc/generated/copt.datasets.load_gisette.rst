﻿copt.datasets.load\_gisette
===========================

.. currentmodule:: copt.datasets

.. autofunction:: load_gisette