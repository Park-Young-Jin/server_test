﻿copt.minimize\_primal\_dual
===========================

.. currentmodule:: copt

.. autofunction:: minimize_primal_dual