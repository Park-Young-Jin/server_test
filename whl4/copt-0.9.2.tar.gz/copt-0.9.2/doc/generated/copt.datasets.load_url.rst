﻿copt.datasets.load\_url
=======================

.. currentmodule:: copt.datasets

.. autofunction:: load_url