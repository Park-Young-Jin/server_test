﻿copt.minimize\_sfw
==================

.. currentmodule:: copt

.. autofunction:: minimize_sfw