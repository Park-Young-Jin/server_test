﻿copt.loss.HuberLoss
===================

.. currentmodule:: copt.loss

.. autoclass:: HuberLoss

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~HuberLoss.__init__
      ~HuberLoss.f_grad
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~HuberLoss.lipschitz
   
   