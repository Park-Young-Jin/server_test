﻿copt.utils.Trace
================

.. currentmodule:: copt.utils

.. autoclass:: Trace

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Trace.__init__
   
   

   
   
   