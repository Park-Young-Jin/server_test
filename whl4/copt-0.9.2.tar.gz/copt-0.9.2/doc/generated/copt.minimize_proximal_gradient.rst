﻿copt.minimize\_proximal\_gradient
=================================

.. currentmodule:: copt

.. autofunction:: minimize_proximal_gradient