﻿copt.constraint.TraceBall
=========================

.. currentmodule:: copt.constraint

.. autoclass:: TraceBall

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TraceBall.__init__
      ~TraceBall.lmo
      ~TraceBall.prox
      ~TraceBall.prox_factory
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TraceBall.is_separable
   
   