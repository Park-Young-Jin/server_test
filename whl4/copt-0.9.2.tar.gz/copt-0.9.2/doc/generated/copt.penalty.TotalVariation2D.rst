﻿copt.penalty.TotalVariation2D
=============================

.. currentmodule:: copt.penalty

.. autoclass:: TotalVariation2D

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TotalVariation2D.__init__
      ~TotalVariation2D.prox
   
   

   
   
   