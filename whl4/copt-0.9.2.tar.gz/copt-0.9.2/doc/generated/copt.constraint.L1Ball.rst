﻿copt.constraint.L1Ball
======================

.. currentmodule:: copt.constraint

.. autoclass:: L1Ball

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~L1Ball.__init__
      ~L1Ball.lmo
      ~L1Ball.lmo_pairwise
      ~L1Ball.prox
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~L1Ball.p
   
   