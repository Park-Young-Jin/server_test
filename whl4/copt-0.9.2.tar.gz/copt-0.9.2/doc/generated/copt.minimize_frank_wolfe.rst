﻿copt.minimize\_frank\_wolfe
===========================

.. currentmodule:: copt

.. autofunction:: minimize_frank_wolfe