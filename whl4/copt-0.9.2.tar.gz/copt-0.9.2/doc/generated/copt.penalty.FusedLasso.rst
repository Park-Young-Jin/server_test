﻿copt.penalty.FusedLasso
=======================

.. currentmodule:: copt.penalty

.. autoclass:: FusedLasso

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~FusedLasso.__init__
      ~FusedLasso.prox
      ~FusedLasso.prox_1_factory
      ~FusedLasso.prox_2_factory
   
   

   
   
   