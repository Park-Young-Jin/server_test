﻿copt.penalty.L1Norm
===================

.. currentmodule:: copt.penalty

.. autoclass:: L1Norm

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~L1Norm.__init__
      ~L1Norm.prox
      ~L1Norm.prox_factory
   
   

   
   
   