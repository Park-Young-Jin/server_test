﻿copt.constraint.LinfBall
========================

.. currentmodule:: copt.constraint

.. autoclass:: LinfBall

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LinfBall.__init__
      ~LinfBall.prox
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~LinfBall.p
   
   