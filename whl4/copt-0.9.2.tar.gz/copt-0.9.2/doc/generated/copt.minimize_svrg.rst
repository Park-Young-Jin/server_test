﻿copt.minimize\_svrg
===================

.. currentmodule:: copt

.. autofunction:: minimize_svrg