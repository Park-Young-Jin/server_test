﻿copt.constraint.L2Ball
======================

.. currentmodule:: copt.constraint

.. autoclass:: L2Ball

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~L2Ball.__init__
      ~L2Ball.prox
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~L2Ball.p
   
   