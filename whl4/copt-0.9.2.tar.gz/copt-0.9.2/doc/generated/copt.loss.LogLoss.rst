﻿copt.loss.LogLoss
=================

.. currentmodule:: copt.loss

.. autoclass:: LogLoss

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~LogLoss.__init__
      ~LogLoss.expit_b
      ~LogLoss.f_grad
      ~LogLoss.hessian_mv
      ~LogLoss.hessian_trace
      ~LogLoss.logsig
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~LogLoss.lipschitz
      ~LogLoss.max_lipschitz
      ~LogLoss.partial_deriv
   
   