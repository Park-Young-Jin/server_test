﻿copt.penalty.TraceNorm
======================

.. currentmodule:: copt.penalty

.. autoclass:: TraceNorm

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TraceNorm.__init__
      ~TraceNorm.prox
      ~TraceNorm.prox_factory
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TraceNorm.is_separable
   
   