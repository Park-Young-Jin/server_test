﻿copt.datasets.load\_madelon
===========================

.. currentmodule:: copt.datasets

.. autofunction:: load_madelon