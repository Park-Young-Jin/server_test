
:orphan:

.. _sphx_glr_auto_examples_sg_execution_times:

Computation times
=================
**04:26.417** total execution time for **auto_examples** files:

+-------------------------------------------------------------------------------+-----------+----------+
| :ref:`sphx_glr_auto_examples_plot_saga_vs_svrg.py` (``plot_saga_vs_svrg.py``) | 04:11.625 | 16.1 MB  |
+-------------------------------------------------------------------------------+-----------+----------+
| :ref:`sphx_glr_auto_examples_plot_jax_copt.py` (``plot_jax_copt.py``)         | 00:05.863 | 113.5 MB |
+-------------------------------------------------------------------------------+-----------+----------+
| :ref:`sphx_glr_auto_examples_plot_accelerated.py` (``plot_accelerated.py``)   | 00:04.677 | 12.2 MB  |
+-------------------------------------------------------------------------------+-----------+----------+
| :ref:`sphx_glr_auto_examples_plot_group_lasso.py` (``plot_group_lasso.py``)   | 00:04.253 | 10.9 MB  |
+-------------------------------------------------------------------------------+-----------+----------+
