Utility functions
=================

Datasets
--------

.. autosummary::
   :toctree: generated/

    copt.datasets.load_img1
    copt.datasets.load_rcv1
    copt.datasets.load_url
    copt.datasets.load_covtype
    copt.datasets.load_gisette
    copt.datasets.load_madelon

Misc
----

.. autosummary::
   :toctree: generated/

    copt.utils.Trace
