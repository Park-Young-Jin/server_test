.. _pytorch_examples:

PyTorch integration
------------------

Examples that optimize PyTorch functions.