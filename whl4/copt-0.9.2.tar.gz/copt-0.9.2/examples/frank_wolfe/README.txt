.. _frank_wolfe_examples:

Frank-Wolfe
-----------

Examples based on the Frank-Wolfe algorithm
