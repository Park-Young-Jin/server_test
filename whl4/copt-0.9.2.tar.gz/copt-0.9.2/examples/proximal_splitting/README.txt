.. _proximal_splitting_examples:

Proximal Splitting
------------------

Examples that use proximal splitting methods.