.. _general_examples:

Example Gallery
===============

Miscellaneous examples
----------------------

Miscellaneous and introductory examples for copt.