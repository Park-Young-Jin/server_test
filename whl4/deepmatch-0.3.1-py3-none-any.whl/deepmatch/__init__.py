from .utils import check_version

__version__ = '0.3.1'
check_version(__version__)
