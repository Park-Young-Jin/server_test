import unittest

from ..AutoViz_Class import AutoViz_Class

class TestAutoVizClass:
    def test_add_plots(self):
        return True
