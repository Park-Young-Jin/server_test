# -*- coding: utf-8 -*-
"""
This package contains the qt designer files and ui scripts.
"""
