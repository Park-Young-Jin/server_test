# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# Copyright (c) 2009- Spyder Kernels Contributors
#
# Licensed under the terms of the MIT License
# (see spyder_kernels/__init__.py for details)
# -----------------------------------------------------------------------------

"""
Site package for the console kernel

NOTE: This package shouldn't be imported at **any** place.
      It's only used to set additional functionality for
      our consoles.
"""
