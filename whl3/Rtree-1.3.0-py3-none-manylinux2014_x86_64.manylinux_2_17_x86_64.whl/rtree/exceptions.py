from __future__ import annotations


class RTreeError(Exception):
    "RTree exception, indicates a RTree-related error."

    pass
