## Info
Create a toolbar so that different text themes can be selected from the UI.

## Original Source
This extension originally comes from [@jld23](https://github.com/jld23)'s [GitHub repository](https://github.com/jld23/IPython-notebook-extensions).


## License

The MIT License (MIT)

Copyright (c) 2016 SAS Institute
