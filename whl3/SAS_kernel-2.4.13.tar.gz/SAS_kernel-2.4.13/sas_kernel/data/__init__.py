import os
_dataRoot = os.path.abspath(os.path.dirname(__file__))
print (_dataRoot)