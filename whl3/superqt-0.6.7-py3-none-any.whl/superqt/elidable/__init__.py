from ._eliding_label import QElidingLabel
from ._eliding_line_edit import QElidingLineEdit

__all__ = ["QElidingLabel", "QElidingLineEdit"]
