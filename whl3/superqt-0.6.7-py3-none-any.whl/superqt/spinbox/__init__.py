from ._intspin import QLargeIntSpinBox

__all__ = ["QLargeIntSpinBox"]
